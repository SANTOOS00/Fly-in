import sys
from parser_constraints import Parser, ParserError
from network_of_drones import Graph
from pathfinding_and_algorithm import Path
from drawing_and_simulation import Draw


class Flyin:

    def main_fly(self) -> None:
        args_len = len(sys.argv)
        if args_len == 2:
            data = Parser.parser_file(sys.argv[1])
        elif args_len == 1:
            raise ParserError("no args provided! try again")
        else:
            raise ParserError(
                "too many args were given, provide only the input file name !"
                )
        network = Graph.make_network(data)
        hubs, connections, drones = network
        paths = Path.find_paths(hubs)
        if not paths:
            raise ParserError("no path found !")

        Draw.draw_and_simu(
            paths, connections, drones, hubs[data['end_hub']['name']], hubs,

            )


if __name__ == "__main__":

    try:
        fly = Flyin()
        fly.main_fly()
    except Exception as error:
        print(f"Error: {error}")
    except KeyboardInterrupt:
        print("Error: should wait to the end")
