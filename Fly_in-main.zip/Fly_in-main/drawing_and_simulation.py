import pygame
from typing import List, Dict
from network_of_drones import Connection, Zone, Drone


class Draw:
    """
    This class for Draw
    """
    @staticmethod
    def draw_and_simu(
            paths: List[List[Zone]], connections: List[Connection],
            drones: List[Drone], end_hub: Zone, hubs: Dict[str, Zone],
            ) -> None:
        """
        method for drawing and simulation

        :param paths: this represent the paths that drones will take
        :type paths: List[List[Zone]]
        :param connections: this hold the zones connected
        :type connections: List[Connection]
        :param drones: this containt owr drones
        :type drones: List[Drone]
        :param end_hub: this for the goal zone for all drones
        :type end_hub: Zone
        :param hubs: this for all hubs in the map
        :type hubs: Dict[str, Zone]
        """

        pygame.init()
        s = pygame.display.set_mode((3800, 2000), pygame.RESIZABLE)
        f = pygame.font.SysFont('Arial', 15, True)
        pygame.display.set_caption("Fly-in")

        c_h = 900
        c_w = 100
        colors = {
            "green": (0, 255, 0), "red": (255, 0, 0), "black": (0, 0, 0),
            "blue": (0, 0, 255), "yellow": (255, 255, 0),
            "maroon": (128, 0, 0), "darkred": (139, 0, 0),
            "orange": (255, 165, 0), "cyan": (0, 255, 255),
            "brown": (165, 42, 42), "magenta": (255, 0, 255),
            "purple": (128, 0, 128), "gold": (255, 215, 0),
            "crimson": (220, 20, 60), "violet": (148, 0, 211)
            }

        start_zone = paths[0][0]
        for d in drones:
            start_zone.current_drones.append(d)
        turn = 1
        in_end_hub = []
        if len(paths[0]) < len(paths[1]):
            for i in range(len(drones)):
                drones[i].my_path = paths[0]
        else:
            for i in range(len(drones)):
                drones[i].my_path = paths[1]

        running = True
        clock = pygame.time.Clock()
        scroll_x = 0
        scroll_y = 0
        scroll_speed = 200
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            s.fill((30, 30, 30))
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                scroll_x -= scroll_speed
            if keys[pygame.K_RIGHT]:
                scroll_x += scroll_speed
            if keys[pygame.K_UP]:
                scroll_y -= scroll_speed
            if keys[pygame.K_DOWN]:
                scroll_y += scroll_speed
            for c in connections:
                pygame.draw.line(
                    s, (192, 192, 192),
                    (c_w + c.from_hub.x * 150 - scroll_x,
                     c_h + c.from_hub.y * 150 - scroll_y),
                    (c_w + c.to_hub.x * 150 - scroll_x,
                     c_h + c.to_hub.y * 150 - scroll_y)
                    )
            for h in hubs:
                x = c_w + hubs[h].x * 150 - scroll_x
                y = c_h + hubs[h].y * 150 - scroll_y
                if hubs[h].color in colors:
                    pygame.draw.circle(
                        s, colors[hubs[h].color], (x, y), 25
                        )
                else:
                    pygame.draw.circle(s, (128, 128, 128), (x, y), 25)
                t_i = f.render(hubs[h].name, True, (255, 255, 255))
                s.blit(t_i, (x - 40, y - 40))
            if drones:
                print(f"{turn}:", end="")
                f_t = pygame.font.SysFont("Arial", 40, True)
                t = f_t.render(f"Turn: {str(turn)}", True, (255, 255, 255))
                s.blit(t, (50, 50))
                if start_zone.current_drones:
                    x = c_w + start_zone.x * 150 - scroll_x
                    y = c_h + start_zone.y * 150 - scroll_y
                    pygame.draw.circle(s, (255, 255, 255), (x, y), 15)
                for c in connections:
                    in_c = False
                    for d in drones:
                        if c == d.conn:
                            in_c = True
                            break
                    if not in_c:
                        c.current_usage = 0
                for d in drones:
                    old_hub = d.my_path[d.i]
                    new_hub = d.my_path[d.i + 1]
                    for c in connections:
                        if c.to_hub == old_hub and c.from_hub == new_hub:
                            c_conn = c
                            break
                        if c.from_hub == old_hub and c.to_hub == new_hub:
                            c_conn = c
                            break
                    if d.in_connection:
                        if d.conn and d.conn.to_hub.has_capacity():
                            d.conn.to_hub.current_drones.append(d)
                            x = c_w + d.conn.to_hub.x * 150 - scroll_x
                            y = c_h + d.conn.to_hub.y * 150 - scroll_y
                            pygame.draw.circle(
                                s, (255, 255, 255), (x, y), 15
                                )
                            t_i = f.render(d.id, True, (0, 0, 0))
                            s.blit(t_i, (x - 10, y - 10))
                            d.conn.current_drones.remove(d)
                            d.conn.current_usage -= 1
                            d.i += 1
                            print(f" {d.id}-{d.conn.to_hub.name}", end="")
                            d.in_connection = False
                            if d.conn.to_hub.name == end_hub.name:
                                in_end_hub.append(d)
                        else:
                            print(f" {d.id}-{c.name}", end="")
                        continue
                    if new_hub.zone == "restricted":
                        c = c_conn
                        if c.has_capacity():
                            c.current_drones.append(d)
                            corr_c_x = (c.from_hub.x + c.to_hub.x) / 2
                            corr_c_y = (c.from_hub.y + c.to_hub.y) / 2
                            x = int(c_w + corr_c_x * 150) - scroll_x
                            y = int(c_h + corr_c_y * 150) - scroll_y
                            pygame.draw.circle(
                                s, (255, 255, 255), (x, y), 15
                                )
                            t_i = f.render(d.id, True, (0, 0, 0))
                            s.blit(t_i, (x - 10, y - 10))
                            old_hub.current_drones.remove(d)
                            d.conn = c
                            d.in_connection = True
                            c.current_usage += 1
                            print(f" {d.id}-{c.name}", end="")
                        else:
                            if old_hub.n != 1:
                                print(
                                    f" {d.id}-{old_hub.name}", end=""
                                    )
                    else:
                        c = c_conn
                        if new_hub.has_capacity() and c.has_capacity():
                            new_hub.current_drones.append(d)
                            x = c_w + new_hub.x * 150 - scroll_x
                            y = c_h + new_hub.y * 150 - scroll_y
                            pygame.draw.circle(
                                s, (255, 255, 255), (x, y), 15
                                )
                            t_i = f.render(d.id, True, (0, 0, 0))
                            s.blit(t_i, (x - 10, y - 10))
                            old_hub.current_drones.remove(d)
                            d.i += 1
                            c.current_usage += 1
                            print(f" {d.id}-{new_hub.name}", end="")
                        else:
                            if old_hub.n != 1:
                                print(f" {d.id}-{old_hub.name}", end="")
                    if new_hub.name == end_hub.name:
                        in_end_hub.append(d)
                for d in in_end_hub:
                    if d in drones:
                        drones.remove(d)
                in_end_hub.clear()
                turn += 1
                print("\n")
                pygame.display.flip()
                clock.tick(2)

        pygame.quit()
