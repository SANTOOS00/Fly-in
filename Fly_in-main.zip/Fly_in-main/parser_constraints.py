from typing import Dict, Any, List, Tuple


class ParserError(Exception):
    """This class for errors in parser of file"""
    pass


class Parser:

    """
    This is for Parser the input file
    """
    @staticmethod
    def parser_file(in_file: str) -> Dict[str, Any]:
        """
        Docstring for parser_file

        :param in_file: it is hold the map file
        :type in_file: str
        :return: the data of the map hubs and connections
        :rtype: Dict[str, Any]
        """
        info: Dict[str, Any] = {}
        with open(in_file, "r") as f:
            empty = True
            for r in f.read():
                if r != " " and r != "\n":
                    empty = False
                    break
            if empty:
                raise ParserError("the input file is empty")
            f.seek(0)
            line = f.readline()
            ll = 1
            first_line = True
            uniqe_hubs: List[str] = []
            names: List[str] = []
            coordinate: List[Tuple[int, int]] = []
            connections: List[List[str]] = []
            meta: List[str] = []
            h = 0
            c = 1
            while (line):
                line = line.split("#")[0].strip()
                if not line or line.startswith('#'):
                    line = f.readline()
                    ll += 1
                    continue

                splited = line.split(":")
                if len(splited) != 2:
                    raise ParserError(f"invalid line {ll} in the input file")
                def_l = splited[0].lower()

                if (splited[1].count("[") + splited[1].count("]")) > 2:
                    raise ParserError(
                        f"in line {ll} invalid metadata brackets"
                        )

                if def_l != "nb_drones" and first_line:
                    raise ParserError(
                        f"line {ll} must define the number of drones"
                        )

                elif def_l == "nb_drones" and first_line:
                    try:
                        num = int(splited[1])
                    except ValueError:
                        raise ParserError(
                            f"in line {ll} nb_drones should be number"
                            )
                    if num <= 0:
                        raise ParserError(
                            "The number of drones must be"
                            f" positive integer in line {ll}"
                            )
                    info.update({def_l: num})
                    first_line = False

                elif def_l == "start_hub" or def_l == "end_hub" or\
                        def_l == "hub":
                    if def_l in uniqe_hubs:
                        raise ParserError(
                            f"in line {ll} there is the duplicate info"
                            )
                    if def_l == "start_hub" or def_l == "end_hub":
                        uniqe_hubs.append(def_l)
                    dic_of_hub: Dict[str, Any] = {}
                    data = splited[1].split()
                    name = data[0].lower()
                    if "-" in name or " " in name:
                        raise ParserError(
                            f"in line {ll} invalide name of zone"
                            )
                    try:
                        coords = (int(data[1]), int(data[2]))
                    except ValueError:
                        raise ParserError(f"in line {ll} invalide coords")
                    if name in names or coords in coordinate:
                        raise ParserError(
                            f"in line {ll} there is the duplicate info"
                            )
                    names.append(name)
                    dic_of_hub.update({"name": name})
                    coordinate.append(coords)
                    dic_of_hub.update({"coords": coords})
                    metadata: Dict[str, Any] = {
                        "zone": "normal",
                        "color": None,
                        "max_drones": 1
                    }
                    if def_l == "start_hub" or def_l == "end_hub":
                        metadata.update({'max_drones': info['nb_drones']})

                    zones = ["normal", "blocked", "restricted", "priority"]
                    colors = ["green", "red", "blue", "yellow", "orange",
                              "violet", "cyan", "brown", "magenta", "purple",
                              "black", "maroon", "gold", "darkred", "crimson",
                              "rainbow"]
                    if "[" in splited[1] and "]" in splited[1]:
                        if splited[1].split()[3][0] != "[":
                            raise ParserError(f"in line {ll} missing \'[\'")
                        lis_data = splited[1].split("[")

                        data_str = lis_data[1].strip("]").split()
                        for d in data_str:
                            if len(d.split("=")) != 2:
                                raise ParserError(
                                    f"in line {ll} invalid metadata"
                                    )
                            elem = d.split("=")[0].lower()
                            if elem == "zone":
                                if elem in meta:
                                    raise ParserError(
                                        f"in line {ll} duplicate metadata"
                                        )
                                zone = d.split("=")[1].lower()
                                if zone in zones:
                                    metadata.update({elem: zone})
                                    meta.append(elem)
                                else:
                                    raise ParserError(
                                        f"in line {ll} invalid zone type "
                                        )
                            elif elem == "color":
                                if elem in meta:
                                    raise ParserError(
                                        f"in line {ll} duplicate metadata"
                                        )
                                color = d.split("=")[1].lower()
                                if color in colors:
                                    metadata.update({elem: color})
                                    meta.append(elem)
                            elif elem == "max_drones":
                                if elem in meta:
                                    raise ParserError(
                                        f"in line {ll} duplicate metadata"
                                        )
                                try:
                                    val = int(d.split("=")[1])
                                except ValueError:
                                    raise ParserError(
                                        f"in line {ll} invalid line"
                                        )
                                if def_l == "hub":
                                    if val > 0:
                                        metadata.update({elem: val})

                                    else:
                                        raise ParserError(
                                            f"in line {ll} invalid value "
                                            "the max_drones should be positive"
                                            )
                                meta.append(elem)
                            else:
                                raise ParserError(
                                    f"in line {ll} invalid metadata of hub"
                                    )
                        meta = []

                    elif "[" in splited[1] and "]" not in splited[1] or\
                            "[" not in splited[1] and "]" in splited[1]:
                        raise ParserError(
                            f"in line {ll} invalid metadata brackets")
                    dic_of_hub.update({"metadata": metadata})
                    if def_l == "hub":
                        h += 1
                        info.update({def_l + str(h): dic_of_hub})
                    else:

                        info.update({def_l: dic_of_hub})
                elif def_l == "connection":
                    dic_of_connect: Dict[str, Any] = {}
                    connection = splited[1].split()

                    if len(connection[0].split("-")) != 2 or \
                       0 > len(connection) or len(connection) > 2:
                        raise ParserError(
                            f"in line {ll} invalid connection "
                            "in the input file"
                            )
                    if len(connection) == 2:
                        if "[" in connection[1] and\
                           "]" not in connection[1] or\
                           "[" not in connection[1] and\
                           "]" in connection[1] or connection[1][0] != "[":
                            raise ParserError(
                                f"in line {ll} invalid connection "
                                "missing brackets"
                                )

                    zone1, zone2 = connection[0].split("-")
                    if zone1 not in names or zone2 not in names:
                        raise ParserError(
                            f"in line {ll} invalid zone name "
                            "in the connections"
                            )
                    s = sorted([zone1, zone2])
                    if s in connections:
                        raise ParserError(
                            f"in line {ll} the same connection must"
                            "not appear more than once"
                            )
                    else:
                        connections.append(s)
                        dic_of_connect.update({"from": zone1})
                        dic_of_connect.update({"to": zone2})
                        dic_of_connect.update({"max_link_capacity": 1})
                    if len(connection) == 2:
                        if len(connection[1].strip("[]").split("=")) != 2:
                            raise ParserError(
                                f"in line {ll} invalid metadata in connections"
                                )
                        key, value = connection[1].strip("[]").split("=")
                        try:
                            v = int(value)
                        except ValueError:
                            raise ParserError(
                                f"in line {ll} max_link_capacity "
                                "should be number"
                                )
                        if key == "max_link_capacity" and v > 0:
                            dic_of_connect.update({key: v})
                        else:
                            raise ParserError(
                                f"in line {ll} invalid metadata in connections"
                                )
                    info.update({def_l + str(c): dic_of_connect})
                    c += 1
                else:
                    raise ParserError(
                        f"in line {ll} invalid data in input file"
                        )
                line = f.readline()
                ll += 1
        if "start_hub" not in info or "end_hub" not in info:
            raise ParserError(
                "invalid input file missing start_hub or end_hub zone"
                )
        return info
