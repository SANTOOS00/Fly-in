from typing import List, Dict, Tuple, Any


class Zone:
    """
    This is for creat the zones
    """
    def __init__(
            self, name: str, coords: Tuple[int, int],
            metadata: Dict[str, Any], n: int
            ) -> None:
        """
        This is for information of zone

        :param self: the zone itself
        :param name: name of the zone
        :type name: str
        :param coords: the coordinate of zone in the map
        :type coords: Tuple[int, int]
        :param metadata: metadata of the zone
        :type metadata: Dict[str, Any]
        :param n: to check if zone one of this (start and goal)
        :type n: int
        """
        self.name = name
        self.x, self.y = coords
        self.color = metadata['color']
        self.max_drones = metadata['max_drones']
        self.zone = metadata['zone']
        self.current_drones: List[Drone] = []
        self.neighbors: Dict[str, Zone] = {}
        self.visited = False
        self.n = n
        self.cost = 0
        self.came_from = ""

    def has_capacity(self) -> bool:
        """
        to check if zone has capacity

        :param self: represent the zone
        :return: if zone has capacity or not
        :rtype: bool
        """
        if len(self.current_drones) < self.max_drones:
            return True
        return False

    def p_turns(self) -> int:
        """
        This to see the cost of zone and this prefer priority zone

        :param self: represent the zone
        :return: the turn need to access the zone
        :rtype: int
        """
        if self.zone == "restricted":
            return 2
        if self.zone == "priority":
            return -1
        return 1

    def turns(self) -> int:
        """
        This to see the cost of zone

        :param self: represent the zone
        :return: the turn need to access the zone
        :rtype: int
        """
        if self.zone == "restricted":
            return 2
        return 1


class Connection:
    """
    this for Connections
    """
    def __init__(
            self, from_hub: Zone, to_hub: Zone, max_link_capacity: int
            ) -> None:
        """
        method for information of connectisons

        :param self: represent the connection itself
        :param from_hub: zone where we go from
        :type from_hub: Zone
        :param to_hub: zone where will we go
        :type to_hub: Zone
        :param max_link_capacity: Description
        :type max_link_capacity: int
        """
        self.name = f"{from_hub.name}-{to_hub.name}"
        self.from_hub = from_hub
        self.to_hub = to_hub
        self.max_link_capacity = max_link_capacity
        self.current_drones: List[Drone] = []
        self.current_usage = 0

    def has_capacity(self) -> bool:
        """
        method check if the connection has capacity

        :param self: represent connection it self
        :return: chech if connection has capacity or not
        :rtype: bool
        """
        if self.current_usage < self.max_link_capacity:
            return True
        return False


class Drone:
    """
    class for creat Drones
    """
    def __init__(self, id: str) -> None:
        """
        method for information of Drones

        :param self: represent the drone itself
        :param id: the id of drone
        :type id: str
        """
        self.id = id
        self.i = 0
        self.my_path: List[Zone] = []
        self.conn: Connection | None = None
        self.in_connection = False


class Graph:

    """
    this for Graph of map
    """
    @staticmethod
    def make_network(
            data: Dict[str, Any]
                    ) -> Tuple[Dict[str, Zone], List[Connection], List[Drone]]:
        """
        method for make network of hubs

        :param data: this hold the hubs and connections and number of drones
        :type data: Dict[str, Any]
        :return: tuple that containt dict of zones
                 and list of connection and drones
        :rtype: Tuple[Dict[str, Zone], List[Connection], List[Drone]]
        """
        hubs: List[Dict[str, Any]] = []
        connections: List[Dict[str, Any]] = []
        hubs.append(data["start_hub"])
        i = 1
        x = 1
        for d in data:
            if d == "hub" + str(i):
                hubs.append(data[d])
                i += 1
            if d == "connection" + str(x):
                connections.append(data[d])
                x += 1
        hubs.append(data["end_hub"])

        hubs_dict: Dict[str, Zone] = {}
        s_zone = Zone(
                hubs[0]['name'], hubs[0]['coords'], hubs[0]['metadata'], 1
                )
        e_zone = Zone(
                hubs[-1]['name'], hubs[-1]['coords'], hubs[-1]['metadata'], -1
                )
        hubs_dict[s_zone.name] = s_zone
        hubs_dict[e_zone.name] = e_zone
        j = 1
        while j < len(hubs) - 1:
            zone = Zone(
                hubs[j]['name'], hubs[j]['coords'], hubs[j]['metadata'], 0
                )
            hubs_dict[zone.name] = zone
            j += 1

        all_links: List[Connection] = []
        for c in connections:

            zone_a = hubs_dict[c['from']]
            zone_b = hubs_dict[c['to']]

            conn = Connection(zone_a, zone_b, c['max_link_capacity'])
            all_links.append(conn)

            zone_a.neighbors[zone_b.name] = zone_b
            zone_b.neighbors[zone_a.name] = zone_a
        drones_list: List[Drone] = []
        for i in range(data['nb_drones']):
            drones_list.append(Drone(f"D{i+1}"))
        return hubs_dict, all_links, drones_list
