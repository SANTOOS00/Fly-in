from typing import Dict, List
from network_of_drones import Zone


class Path:
    """
    This is for pathfinding
    """
    @staticmethod
    def find_paths(hubs: Dict[str, Zone]) -> List[List[Zone]]:
        """
        method for find_paths

        :param hubs: represent the hubs in the map
        :type hubs: Dict[str, Zone]
        :return: the list of paths
        :rtype: List[List[Zone]]
        """
        zones: List[Zone] = []
        for h in hubs:
            if hubs[h].n == 1:
                start = h
            if hubs[h].n == -1:
                end = h

        zones.append(hubs[start])
        i = 0
        paths: List[List[Zone]] = []
        v_zones: List[Zone] = []
        while i < 2:
            while zones:
                s_zones = sorted(zones, key=lambda z: z.cost)
                current_zone = s_zones[0]
                current_zone.visited = True
                zones.remove(s_zones[0])
                v_zones.append(current_zone)

                neighbors = current_zone.neighbors
                for n in neighbors:
                    if not neighbors[n].visited:
                        if i == 0:
                            n_cost = current_zone.cost + neighbors[n].turns()
                        elif i == 1:
                            n_cost = current_zone.cost + neighbors[n].p_turns()
                        if neighbors[n].cost == 0:
                            neighbors[n].cost = n_cost
                            zones.append(neighbors[n])
                            neighbors[n].came_from = current_zone.name

                if hubs[end].visited:
                    path: List[Zone] = []
                    path.append(hubs[end])

                    h = hubs[end].came_from
                    while hubs:
                        if hubs[h].name == start:
                            path.append(hubs[h])
                            break
                        path.append(hubs[h])
                        h = hubs[h].came_from

                    paths.append(path[::-1])
            for z in v_zones:
                z.visited = False
                z.cost = 0
            zones.append(hubs[start])
            i += 1
        return paths
