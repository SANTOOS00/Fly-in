*This project has been created as part of the 42 curriculum by abait-sa*

# . Description
Fly_in is one of the projects I have enjoyed the most, you have group of drones you should to recommend them from start zone to end zone in the fewest number of turns, They will pass through a series of zones maybe restricted zone take (2 turns) or normal take (1 turn) or priority take (1 turn ) but she will preferred if there way to normal and way to priority or blocked (inaccessible — cannot be entered), and all of that is graph representing network of connected zones, where connections define possible movement paths between zones.

# . Instructions
in the fist we will use virtual environment with command:
python3 -m venv my_env
and to activate the venv we do : 
source my_env/bin/activate
after that we will be in the venv so we do this command to install dependencies like(pygame and mypy and flake8):
make intall
after that we will create file with name "maps.txt" she will be hold the data of owr hubs and drones and connection and this data we  will intalled the file in the page of correction with name  "maps.tar.gz" we unzip the file and she hold data of different maps and we will one of this maps in the file "maps.txt", after all that use this command to execute the main script of your project:
make run
and if you want to remove temporary files or caches (e.g., __pycache__, .mypy_cache) to
keep the project environment clean:
make clean
and to check type hints and flake8 do this command:
make lint or make lint-strict

# . Resources
my resources in this projects the first is AI she help me to understand my alghorithm and visual representation
and this channel in youtube with name "Ahmed Hashim" too he explain the alghorithm very well
and the visual representation the link too help for understand the pygame library
https://deepnote.com/blog/ultimate-guide-to-pygame-library-in-python


## . Additional
. my algorithm is djikstra what she do she give us the shortestpath with using the cost between zone and how many turns the drone take to be in end zone for example if it is in zone and she have a way to normal zone take 1 turn and  restricted that take 2 turn she will be shose the normal zone ok after chosen the zone check the neighbors of the zone and take the less zone cost if it arrived the goal zone she will stop and return the path 

. in the visual representation i use the pygame library of python modules designed for writing games and multimedia programs, and some of this modules:
pygame.display : manages the game window or screen and the display surface where you  render graphics.
pygame.draw : contains functions to draw shepes(lines, circles) directly onto surfaces.
pygame.event: hanles the event queue, which collects input events like key presses, mouse movements, quit signals.
pygame.time: utilities for timing and framerate control (e.g., a Clock class to regulate your game loop speed).
pygame.font: enables rendering text onto surfaces using different fonts.
